<?php
header('Content-Type: application/json'); // Assicurati che l'header JSON sia presente
include 'connessione.php';

// Ottieni tutte le stanze che sono disponibili (stato = 'aperta')
// e che non hanno ancora un secondo giocatore (giocatore2_id IS NULL)
$sql = "SELECT id, nome, host_id, host_ip FROM stanze WHERE stato = 'aperta' AND giocatore2_id IS NULL";
$result = $conn->query($sql);

$stanze = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $stanze[] = $row;
    }
}

echo json_encode($stanze);

$conn->close();
?>